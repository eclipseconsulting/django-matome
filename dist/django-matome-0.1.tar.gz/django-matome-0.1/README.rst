=====
Matome
=====

Matome is a Django app to see stats about your project.

Quick start
-----------

1. Add "matome" to your INSTALLED_APPS setting like this:

    INSTALLED_APPS = [
        ...
        'matome',
    ]



2. Run ``python manage.py matome`` to see stats.
